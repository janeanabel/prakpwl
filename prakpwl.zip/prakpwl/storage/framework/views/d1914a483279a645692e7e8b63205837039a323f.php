

<?php $__env->startSection('content'); ?>
<h1>Ini adalah halaman about</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\prakpwl\resources\views/v_about.blade.php ENDPATH**/ ?>