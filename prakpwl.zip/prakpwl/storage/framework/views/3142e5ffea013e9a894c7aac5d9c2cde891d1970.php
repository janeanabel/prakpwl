

<?php $__env->startSection('content'); ?>
<h1>Nip : <?php echo e($nip1); ?> </h1>
<h1>Nama : <?php echo e($nama1); ?> </h1>
<h1>Matkul <?php echo e($matkul1); ?></h1><br><br>

<h1>Nip : <?php echo e($nip2); ?> </h1>
<h1>Nama : <?php echo e($nama2); ?> </h1>
<h1>Matkul <?php echo e($matkul2); ?></h1><br><br>

<h1>Nip : <?php echo e($nip3); ?> </h1>
<h1>Nama : <?php echo e($nama3); ?> </h1>
<h1>Matkul <?php echo e($matkul3); ?></h1><br><br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\prakpwl\resources\views/dosen.blade.php ENDPATH**/ ?>