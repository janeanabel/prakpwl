@extends('layout.template')

@section('content')
<h1>Nip : {{ $nip1 }} </h1>
<h1>Nama : {{$nama1 }} </h1>
<h1>Matkul {{ $matkul1 }}</h1><br><br>

<h1>Nip : {{ $nip2 }} </h1>
<h1>Nama : {{$nama2 }} </h1>
<h1>Matkul {{ $matkul2 }}</h1><br><br>

<h1>Nip : {{ $nip3 }} </h1>
<h1>Nama : {{$nama3 }} </h1>
<h1>Matkul {{ $matkul3 }}</h1><br><br>

@endsection