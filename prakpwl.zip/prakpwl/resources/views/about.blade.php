@extends('layout.template')
@section('content')
<h1>Ini adalah halaman about</h1>
@endsection