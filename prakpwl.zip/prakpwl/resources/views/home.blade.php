@extends('layout.template')

@section('content')
<h1>Ini adalah halaman home</h1>
<h1>{{ $kelas }}</h1>
<h1>{{ $prodi }}</h1>
@endsection